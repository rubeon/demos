require 'spec_helper'

describe 'rackspace_logrotate::global' do
  let(:chef_run) { ChefSpec::Runner.new.converge(described_recipe) }

  it 'includes the default recipe' do
    expect(chef_run).to include_recipe('rackspace_logrotate::default')
  end

  it 'writes the configuration template' do
    template = chef_run.template('/etc/logrotate.conf')
    expect(template).to be
    expect(template.source).to eq('logrotate-global.erb')
    expect(template.mode).to eq('0644')
  end
end
