CONTRIBUTING
===========

See the [contributing guide](https://github.com/rackspace-cookbooks/contributing/blob/master/CONTRIBUTING.md) for more details
