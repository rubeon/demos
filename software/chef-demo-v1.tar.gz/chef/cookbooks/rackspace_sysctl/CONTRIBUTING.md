# How to Contribute

We would like to encourage you to contribute to this repository.
This should be as easy as possible for you but there are a few things to consider when contributing.

* Please read the [main contribution guide](https://github.com/rcbops/chef-cookbooks/blob/master/CONTRIBUTING.md).
* Please read the [README](README.md) for this repository if you have not done so already.
* Please read the [testing guide](TESTING.md) for this repository if one exists.

Lastly, thank you for taking the time to contribute and making this better!
