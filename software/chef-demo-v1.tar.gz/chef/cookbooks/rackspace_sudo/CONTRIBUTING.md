# Contributing to Rackspace Cookbooks

* Please see [contributing.md](https://github.com/rackspace-cookbooks/contributing/blob/master/CONTRIBUTING.md) for more details
