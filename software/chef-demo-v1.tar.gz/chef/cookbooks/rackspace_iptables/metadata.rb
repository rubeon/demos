name             'rackspace_iptables'
maintainer       'Rackspace, US Inc.'
maintainer_email 'rackspace-cookbooks@rackspace.com'
license          'Apache 2.0'
description      'Installs/Configures rackspace_iptables'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '1.2.0'
