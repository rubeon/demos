name              'rackspace_iptables_test'
maintainer        'Rackspace, US Inc.'
maintainer_email  'rackspace-cookbooks@rackspace.com'
license           'Apache 2.0'
description       'This cookbook is used with test-kitchen to test the parent cookbook, rackspace_iptables'
version           '1.0.0'

depends           'rackspace_iptables'
