# Installs a .my.cnf file into /root containing the root mysql credentials
default['rackspace_mysql']['install_root_my_cnf'] = false
