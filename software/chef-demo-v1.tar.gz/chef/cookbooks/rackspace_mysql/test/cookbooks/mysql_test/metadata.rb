name 'mysql_test'
version '0.1.0'

depends 'rackspace_database'
depends 'rackspace_yum'
