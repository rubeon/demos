Contributing
============
1. Fork it
2. Create your feature branch (`git checkout -b my-new-feature`)
3. Commit your changes (`git commit -am 'Add some feature'`)
4. **Add tests!**
5. Push to the branch (`git push origin my-new-feature`)
6. Create new Pull Request

Is the Chef CCLA required?
-------------
As this cookbook is no longer maintained by Chef, you **do not** need to sign any sort of contributor agreement. Simply make your change and open a pull request.

Do I need to open a JIRA ticket at https://tickets.opscode.com ?
-------------
Nope! We use GitHub issues to track issues and requests.
