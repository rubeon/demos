# CHANGELOG for motd

This file is used to list changes made in each version of motd.

## 1.0.0:
* Move namespace `rackspace_motd`
* add testing via test-kitchen
* remove dependency on motd-tail cookbook
* added chefspec tests
* added strainer and thor tasks

## 0.1.0:
* Initial release of motd
