# Contributing to Rackspace Cookbooks

Please see https://github.com/rackspace-cookbooks/contributing for up
to date information.
