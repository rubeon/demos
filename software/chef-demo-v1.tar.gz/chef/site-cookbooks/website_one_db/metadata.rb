name             'website_one_db'
maintainer       ''
maintainer_email 'DevOpsAdvisory-INTL@RACKSPACE.COM'
license          'Apache 2.0'
description      'Installs/Configures website_one_db'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.1.0'
