jboss Cookbook
=======================
Cookbook to install Jboss and deploy applications 


Requirements
------------


Attributes
----------

Usage
-----

Contributing
------------

License and Authors
-------------------
