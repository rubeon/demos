
default["website_one"]["db_host"] = "10.181.102.187"
default["website_one"]["db_user"] = "app"
default["website_one"]["db_name"] = "world"
default["website_one"]["db_pass_data_bag_item"] = "mysql_app"

default["website_one"]["site_root"] = "/srv/www/"
default["website_one"]["site_remote_url"] = "https://github.com/bigcloudsolutions/demos/raw/master/demo-sites/one.example.com.tar.gz"
default["website_one"]["site_remote_filename"] = "one.example.com.tar.gz"
default["website_one"]["site_db_conf"]  = "/srv/www/one.example.com.db.php"


