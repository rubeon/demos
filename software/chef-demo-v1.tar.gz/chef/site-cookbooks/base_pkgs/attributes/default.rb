default["package_list"] = [
"strace",
"screen",
"mlocate",
"lsof",
"tcpdump",
"sysstat",
"iotop"
]
