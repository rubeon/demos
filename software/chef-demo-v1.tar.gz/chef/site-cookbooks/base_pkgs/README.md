base_pkgs Cookbook
=======================

Installs base packages. This cookbook is an example of using attrbutes in cookbook to define the list of packages


Requirements
------------


Attributes
----------
See default.rb

Usage
-----

Contributing
------------

License and Authors
-------------------
