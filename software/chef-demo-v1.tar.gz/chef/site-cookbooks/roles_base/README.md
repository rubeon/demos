roles_base Cookbook
=======================

Role book for the base role
See metadata.rb for list of coookbooks this depends on

Requirements
------------


Attributes
----------

Usage
-----

Contributing
------------

License and Authors
-------------------
