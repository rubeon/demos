# encoding: UTF-8

require 'chefspec'
