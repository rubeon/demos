roles_app Cookbook
=======================

Role book for the app role

Requirements
------------


Attributes
----------

Usage
-----

Contributing
------------

License and Authors
-------------------
