jboss_app Cookbook
=======================
Install a jboss application

Requirements
------------


Attributes
----------

Usage
-----

Contributing
------------

License and Authors
-------------------
