default['jboss_app']['wars'] = [ "jboss-helloworld.war",
                                "jboss-numberguess.war"
                                ]

default['jboss_app']['war_url_base'] = "https://github.com/bigcloudsolutions/demos/raw/master/jboss_webapps/"

#this is relative to Jboss home
default['jboss_app']['webapps_dir'] = 'standalone/deployments/'




