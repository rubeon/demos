<?php

print $_SERVER['SERVER_ADDR']

?>
